package com.bnm.lavy.lavyfinalproject;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

public class CustomView extends View {
    Context context;
    //private Sprite s;
    private float wScreen, hScreen;// screen dimentions
    private Bitmap [] picArr;
    private Board board;

    public CustomView(Context context) {
        super(context);
        this.context =context;
        picArr = new Bitmap[4];
        picArr[0] = BitmapFactory.decodeResource(context.getResources(), R.drawable.photo1);
        picArr[1] = BitmapFactory.decodeResource(context.getResources(), R.drawable.photo2);
        picArr[2] = BitmapFactory.decodeResource(context.getResources(), R.drawable.photo3);
        picArr[3] = BitmapFactory.decodeResource(context.getResources(), R.drawable.photo4);

    }

    @Override
    protected void onDraw(Canvas canvas) {

        //s.draw(canvas);
        board.draw(canvas);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float ex = event.getX();
        float ey = event.getY();
        if ( event.getAction() == MotionEvent.ACTION_DOWN)
        {
            if (board.isInside(ex, ey)) {
                if(board.isLast(ex, ey)) {
                    //Toast.makeText(context, "last", Toast.LENGTH_SHORT).show();
                    board.addSprite();
                    board.cleanBoard();
                    board.mix();
                }
            }
                //Toast.makeText(context, "Inside", Toast.LENGTH_LONG).show();
               // s.setX(s.getX() + 30);
        }
        //Log.d("key_t", "x: " + ex + " y: " + ey);
        invalidate();


        return true;
    }

    @Override
    protected void onSizeChanged(int wS, int hS, int oldw, int oldh) {
        super.onSizeChanged(wS, hS, oldw, oldh);
        wScreen = wS;
        hScreen = hS;
        float w = wScreen/4;
        float h = w/2;
        //s = new Sprite(wScreen/2,hScreen/2, w, h, picFlag);
        //s = new Sprite(wScreen - w,hScreen - h, w, h, null);
        board = new Board(wS, hS, picArr, 2,2 );

    }
}
